import React, { Component } from 'react';
import {StyleSheet, TextInput, View, Text, Alert, TouchableHighlight, Modal,TouchableOpacity } from 'react-native';
import {StackNavigator} from 'react-navigation';
import ForgotPassword from './components/ForgotPassword'

export default class Login extends React.Component{
    constructor(props) {
      super(props);
      this.state={
        username:'',
        password:'',
        res:'',
        load:"Login",
        forgotPasswordModalVisible: false,
        otherParamsToSend: 1,
        };
    }

    btnForgotPassword(){
        this.setState({forgotPasswordModalVisible: true});
    }
	
    callbackAfterForgotPassword(success, otherValue) {
        this.setState({forgotPasswordModalVisible: false});
        console.log("success >> "+success+" otherValue >> "+otherValue);
    }
	
  _handleLoginClick(){
		this.setState({load:"Loading..."});
		fetch("https://ncteamvn.herokuapp.com/oauth/token",{
          method: "POST",
          headers: {"Content-Type": "application/x-www-form-urlencoded"},
          body: "username="+this.state.username+"&password="+this.state.password
		})
		.then((response) => response.json())
		.then((res) => {
			if(res.access_token != undefined){
              res.username = this.state.username;// add uname
              console.log(res);
              this.setState({load:"Login"});
              this.props.navigation.navigate('Home', {userData:res});
			} else {Alert.alert(res.statusText);}
      }).catch((error) => {console.log(error);});
  }

  static navigationOptions = {title:'Login',header:null};
  render() {
    var otherParamsToSend;
    var forgotPasswordModel = 	<Modal transparent={true} visible={this.state.forgotPasswordModalVisible} onRequestClose={() => {this.setState({forgotPasswordModalVisible: false});}}>
									<ForgotPassword callbackAfterForgotPassword={this.callbackAfterForgotPassword.bind(this)} otherParamsToSend={this.state.otherParamsToSend}/>
								</Modal>
    return (   
		<View style={{flex:1}} >
			<View style={{flex:4, backgroundColor:'#0099FF'}}>
				<Text style={styles.login}>Login</Text>
			</View>
			<View style={styles.container}>
				<Text style={{paddingLeft:110,fontSize:20,paddingBottom:30,paddingTop:30, color:'red'}}>BBC warehouse</Text>
				<View style={{paddingLeft:50}}>
					<View>
						<Text style={styles.view1}>Account</Text>
						<TextInput style={styles.view2} placeholder='Your email address'
									placeholderTextColor='#ddd'
									onChangeText={(username) => this.setState({username})}/>
					</View>
					<View>
						<Text style={styles.view1}>Password</Text>
						<TextInput style={styles.view2} placeholder='Password'
							  placeholderTextColor='#ddd' secureTextEntry={true}
							  onChangeText={(password) => this.setState({password})}/>
					</View>
					<View style={{marginBottom:20}}>
						<TouchableOpacity onPress={this.btnForgotPassword.bind(this)}>
							  <Text style={styles.forgot}>FORGOT PASSWORD</Text>
						</TouchableOpacity>
						{forgotPasswordModel}
					</View>
				</View>
				<View style={{marginLeft:50,marginTop:20, backgroundColor:"#33FF66",marginRight:50, borderRadius:20}}>
					<TouchableHighlight onPress={() => {this._handleLoginClick()}}>
						<Text style={styles.load}>{this.state.load}</Text>
					</TouchableHighlight>
				</View>
			</View>
		</View>
    );
  }
}
const styles = StyleSheet.create({
  container: {flex: 8,flexDirection:'column'},
  view1: {width:'30%',height:25,marginRight:10,color:'#555555'},
  view2: {borderBottomWidth:1,borderColor:'#196DF9',height:25,width:'82%',marginBottom:20},
  login: {bottom:20,position:'absolute', color:'#fff', fontSize:20, paddingLeft:30,fontWeight:'bold'},
  forgot: {paddingLeft:120,color:'#0099FF',fontWeight:'bold'},
  load: {paddingTop:10, paddingBottom:10,paddingLeft:110,color:'#fff',fontWeight:'bold'}
});