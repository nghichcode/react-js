const listData = [
        {id:'settings',txt:'Settings',l2Items:[
          {id:'user',txt:'USER',childs:[
            {nav:'CreateUser',txt:'Create User'},
            {nav:'SearchUser',txt:'Search User'},
          ]},
          {id:'role',txt:'ROLE',childs:[
            {nav:'CreateRole',txt:'Create Role'},
            {nav:'SearchRole',txt:'Search Role'}
          ]},
          {id:'none',txt:'NONE',childs:[]}
        ]},
        {id:'groups',txt:'Groups',l2Items:[
          {id:'user',txt:'USER',childs:[
            {nav:'CreateUser',txt:'Create User'},
            {nav:'SearchUser',txt:'Search User'},
          ]},
          {id:'role',txt:'ROLE',childs:[
            {nav:'CreateRole',txt:'Create Role'},
            {nav:'SearchRole',txt:'Search Role'}
          ]},
          {id:'none',txt:'NONE',childs:[]}
        ]}
      ]

export default listData