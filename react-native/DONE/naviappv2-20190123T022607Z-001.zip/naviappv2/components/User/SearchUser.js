import React from 'react'
import {Button} from 'react-native'

export default class SearchUser extends React.Component {
  static navigationOptions = {drawerLabel: 'Search User'};
  render() {return (<Button title="SearchUser" onPress={() => this.props.navigation.goBack()} />);}
}