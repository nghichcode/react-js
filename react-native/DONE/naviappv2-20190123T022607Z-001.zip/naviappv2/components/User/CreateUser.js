import React, { Component } from 'react';
import {StyleSheet, TextInput, View, Text, TouchableHighlight } from 'react-native';

export default class CreateUser extends React.Component{
  render() {
    return (   
		  <View style={{flex:1}} >
			  <View style={{flex:2, backgroundColor:'#0099FF'}}>
				  <Text style={styles.res}>Registration</Text>
			  </View>
		  	<View style={styles.container}>
				  <View style={{paddingLeft:50}}>
            <View>
              <Text style={styles.view1}>First Name</Text>
              <TextInput style={styles.view2} placeholder='ex: An' placeholderTextColor='gray'/>
            </View>
            <View>
              <Text style={styles.view1}>Last Name</Text>
              <TextInput style={styles.view2} placeholder='ex: Nguyen' placeholderTextColor='gray'/>
            </View>
            <View>
              <Text style={styles.view1}>Email</Text>
              <TextInput style={styles.view2} placeholder='Your email address' placeholderTextColor='gray'/>
            </View>
            <View>
              <Text style={styles.view1}>Password</Text>
              <TextInput style={styles.view2} placeholder='**********' placeholderTextColor='gray' secureTextEntry={true}/>
            </View>
            <View>
              <Text style={styles.view1}>Confirm Password</Text>
              <TextInput style={styles.view2} placeholder='**********' placeholderTextColor='gray' />
            </View>
				  </View>
          <View style={{marginLeft:50,marginTop:20, backgroundColor:"#33FF66",marginRight:50, borderRadius:20}}>
            <TouchableHighlight onPress={() => this.props.navigation.goBack()}>
              <Text style={styles.load}>Registration</Text>
            </TouchableHighlight>
          </View>
			  </View>
		  </View>
    );
  }
}
const styles = StyleSheet.create({
  container: {flex: 8,flexDirection:'column', marginTop:20},
  view1: {width:'50%',height:25,marginRight:10},
  view2: {borderBottomWidth:1,borderColor:'#196DF9',height:25,width:'82%',marginBottom:20},
  res: {bottom:20,position:'absolute', color:'#fff', fontSize:20, paddingLeft:30,fontWeight:'bold'},
  load: {paddingTop:10, paddingBottom:10,paddingLeft:100,color:'#fff',fontWeight:'bold'}
});