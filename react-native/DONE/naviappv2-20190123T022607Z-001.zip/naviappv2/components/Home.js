import React, { Component } from 'react';
import {Button, View, Text, Image } from 'react-native';

export default class Home extends React.Component {
  static navigationOptions = {
    drawerLabel: 'Home',
    drawerIcon: ({ tintColor }) => (
      <Image source={require('./assets/snack-icon.png')} style={[{width: 24,height: 24}, {tintColor: tintColor}]} />
  )};
  render() {
    return (
      <View style={{zIndex:1, marginTop:30}}>
        <View style={{zIndex:1}}>
        <Button title="Go to notifications"
          onPress={()=>this.props.navigation.navigate('Notifications')}/>
        <Button title="Pop"
          onPress={()=>this.props.navigation.navigate('DrawerOpen')}/>
        </View>
      </View>
    );
  }
}