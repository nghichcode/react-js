import React from 'react'
import {Button} from 'react-native'

export default class SearchRole extends React.Component {
  static navigationOptions = {drawerLabel: 'Search Role'};
  render() {return (<Button title="SearchRole" onPress={() => this.props.navigation.goBack()} />);}
}