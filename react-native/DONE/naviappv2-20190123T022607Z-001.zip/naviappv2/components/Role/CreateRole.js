import React from 'react'
import {Button} from 'react-native'

export default class CreateRole extends React.Component {
  static navigationOptions = {drawerLabel: 'Create Role'};
  render() {return (<Button title="CreateRole" onPress={() => this.props.navigation.goBack()} />);}
}