import React from 'react';
import { Text,View,StyleSheet,Image,Button,TouchableOpacity } from 'react-native';
import {StackNavigator,DrawerNavigator} from 'react-navigation';
import {Ionicons as Icon} from '@expo/vector-icons';
import { Constants } from 'expo';

import Notifications from './components/Notifications'
import CreateUser from './components/User/CreateUser'
import SearchUser from './components/User/SearchUser'
import SearchRole from './components/Role/SearchRole'
import CreateRole from './components/Role/CreateRole'

class Home extends React.Component {
  static navigationOptions = {
    drawerLabel: 'Home',
    drawerIcon: ({ tintColor }) => (
      <Image source={require('./assets/snack-icon.png')} style={[styles.icon, {tintColor: tintColor}]} />
  )};
  render() {
    return (
      <View style={{zIndex:1, marginTop:30}}>
        <View style={{zIndex:1}}>
        <Button title="Go to notifications"
          onPress={()=>this.props.navigation.navigate('Notifications')}/>
        <Button title="Pop"
          onPress={()=>this.props.navigation.navigate('DrawerOpen')}/>
        </View>
      </View>
    );
  }
}

class MainDrawer extends React.Component {
  constructor(props){
    super(props);
    this.state={
      showSubItems:false, itemName:'', itemL1Name:'',
      items:[
        {id:'settings',txt:'Settings',l2Items:[
          {id:'user',txt:'USER',childs:[
            {nav:'CreateUser',txt:'Create User'},
            {nav:'SearchUser',txt:'Search User'},
          ]},
          {id:'role',txt:'ROLE',childs:[
            {nav:'CreateRole',txt:'Create Role'},
            {nav:'SearchRole',txt:'Search Role'}
          ]},
          {id:'none',txt:'NONE',childs:[]}
        ]},
        {id:'groups',txt:'Groups',l2Items:[
          {id:'user',txt:'USER',childs:[
            {nav:'CreateUser',txt:'Create User'},
            {nav:'SearchUser',txt:'Search User'},
          ]},
          {id:'role',txt:'ROLE',childs:[
            {nav:'CreateRole',txt:'Create Role'},
            {nav:'SearchRole',txt:'Search Role'}
          ]},
          {id:'none',txt:'NONE',childs:[]}
        ]}
      ]
    };
  }
  
  Draw1(props,item,index){
    return(
      <View style={{backgroundColor:'#000'}}>
      <TouchableOpacity style={styles.customDrawerTouch}
        onPress={()=>{this.setState({itemName:this.state.itemName===item.id?'':item.id});}}>
        <View style={[styles.expandButtonRow,styles.btnExpand,styles.activeBackgroundColor]}>
          <Text style={styles.inactiveTintColor}>{item.txt}</Text>
          <Icon name={this.state.itemName===item.id?"ios-arrow-down":"ios-arrow-forward"} size={20} style={styles.customDrawerIcon}/>
        </View>
      </TouchableOpacity>
      {(
        this.state.itemName===item.id?
        item.l2Items.map( (it,i)=>( this.Draw2(props,it,i) ) )
        :null
      )}
      </View>
    );
  }
  Draw2(props,item,index,active){
    return(
      <View style={styles.inactiveBackgroundColor}>
      <TouchableOpacity
        onPress={()=>{this.setState({itemL1Name:this.state.itemL1Name===item.id?'':item.id});}}>
        <View style={[styles.expandButtonRow,styles.activeBackgroundColor]}>
          <Icon name={this.state.itemL1Name===item.id?"ios-arrow-down":"ios-arrow-forward"} size={20} style={{paddingLeft:30, color:'#fff'}}/>          
          <Text style={styles.inactiveTintColor}>{item.txt}</Text>
        </View>
      </TouchableOpacity>
      {(
        this.state.itemL1Name===item.id?
        item.childs.map( (it,i)=>( this.DrawSubItems(props,it.nav,it.txt,this.props.activeItemKey==it.nav?true:false) ) )
        :null
      )}
      </View>
    );
  }

  DrawSubItems(props,nav,txt,active) {
    return (
      <TouchableOpacity
        onPress={()=>{this.props.navigation.navigate(nav);}}>
        <View style={[styles.expandButtonRow,styles.btnExpand]}>
          <Text style={active?styles.inactiveTintColor:styles.activeTintColor}>{txt}</Text>
        </View>
      </TouchableOpacity>
      );
  }

  render(){
    return (<View style={styles.container}>
      <Text style={{textAlign: 'center'}}>Menu Items</Text>
      <View>{this.state.items.map( (it,i)=>(this.Draw1(this.props,it,i)) )}</View>
    </View>);
  }
}

const styles = StyleSheet.create({
  container:{flex: 1,paddingTop: Constants.statusBarHeight},
  customDrawerIcon: { paddingRight: 10, color:'#fff' },
  expandButtonRow: {
    flexDirection: 'row',
    paddingVertical: 12,paddingLeft: 3
  },
  btnExpand:{justifyContent: 'space-between'},
  icon: {width: 24,height: 24},

  activeTintColor: {paddingLeft:100, color:"#fff", fontWeight:'bold'},
  activeBackgroundColor: {backgroundColor:'rgba(0, 0, 0, .04)'},
  inactiveTintColor: {fontWeight: 'bold',color:'#fff', paddingLeft:20},
  inactiveBackgroundColor: {backgroundColor:'gray'},

});

const MyApp = DrawerNavigator({
  Home: {screen: Home},
  CreateUser: {screen:CreateUser},
  SearchUser: {screen: SearchUser},
  CreateRole: {screen:CreateRole},
  SearchRole: {screen: SearchRole},
  Notifications: {screen: Notifications}
  }, {
  contentComponent: MainDrawer
});
export default class App extends React.Component {
  render() { return (<MyApp />); }
}