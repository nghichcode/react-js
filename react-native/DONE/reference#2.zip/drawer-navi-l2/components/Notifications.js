import * as React from 'react';
import { Text, View, Button } from 'react-native';

export default class Notifications extends React.Component {
  static navigationOptions = {drawerLabel: 'Notifications'};
  render() {return (<Button title="Go back home" onPress={() => this.props.navigation.goBack()} />);}
}