import React from 'react'
import {Button} from 'react-native'

export default class CreateUser extends React.Component {
  static navigationOptions = {drawerLabel: 'Creat User'};
  render() {return (<Button title="CreateUser" onPress={() => this.props.navigation.goBack()} />);}
}