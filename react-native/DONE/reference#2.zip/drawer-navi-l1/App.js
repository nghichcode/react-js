import * as React from 'react';
import { Text,View,StyleSheet,Image,Button,Animated,Alert,TouchableOpacity } from 'react-native';
import {StackNavigator,DrawerNavigator,DrawerItems} from 'react-navigation';
import {FontAwesome,Ionicons as Icon} from '@expo/vector-icons';
import { Constants } from 'expo';

class Home extends React.Component {
  static navigationOptions = {
    drawerLabel: 'Home',
    drawerIcon: ({ tintColor }) => (
      <Image source={require('./assets/snack-icon.png')} style={[styles.icon, {tintColor: tintColor}]} />
  )};
  constructor(props){
    super(props);
  }
  render() {
    return (
      <View style={{zIndex:1, marginTop:30}}>
        <View style={{zIndex:1}}>
        <Button title="Go to notifications"
          onPress={()=>this.props.navigation.navigate('Notifications')}/>
        <Button title="Pop"
          onPress={()=>this.props.navigation.navigate('DrawerOpen')}/>
        </View>
      </View>
    );
  }
}
class Notifications extends React.Component {
  static navigationOptions = {drawerLabel: 'Notifications'};
  render() {return (<Button title="Go back home" onPress={() => this.props.navigation.goBack()} />);}
}
class CreateUser extends React.Component {
  static navigationOptions = {drawerLabel: 'Creat User'};
  render() {return (<Button title="CreateUser" onPress={() => this.props.navigation.goBack()} />);}
}
class SearchUser extends React.Component {
  static navigationOptions = {drawerLabel: 'Search User'};
  render() {return (<Button title="SearchUser" onPress={() => this.props.navigation.goBack()} />);}
}
class CreateRole extends React.Component {
  static navigationOptions = {drawerLabel: 'Create Role'};
  render() {return (<Button title="SearchRole" onPress={() => this.props.navigation.goBack()} />);}
}
class SearchRole extends React.Component {
  static navigationOptions = {drawerLabel: 'Search Role'};
  render() {return (<Button title="SearchRole" onPress={() => this.props.navigation.goBack()} />);}
}
class MainDrawer extends React.Component {
  constructor(props){
    super(props);
    this.state={
      showSubItems:false, itemName:'',
      items:[
        {id:'user',txt:'USER',childs:[
          {nav:'CreateUser',txt:'Create User'},
          {nav:'SearchUser',txt:'Search User'},
        ]},
        {id:'role',txt:'ROLE',childs:[
          {nav:'CreateRole',txt:'Create Role'},
          {nav:'SearchRole',txt:'Search Role'}
        ]},
        {id:'none',txt:'NONE',childs:[]}
      ]
    };
  }
  DrawSubItems(props,nav,txt,active) {
    return (
      <TouchableOpacity style={styles.customDrawerTouch}
        onPress={()=>{this.props.navigation.navigate(nav);}}>
        <View style={[styles.expandButtonRow,styles.btnExpand,styles.inactiveBackgroundColor]}>
          <Text style={active?styles.activeTintColor:styles.inactiveTintColor,{paddingLeft:30}}>{txt}</Text>
        </View>
      </TouchableOpacity>
      );
  }
  ButtonParents(props,item,index){
    return(
      <View>
      <TouchableOpacity style={styles.customDrawerTouch}
        onPress={()=>{this.setState({itemName:this.state.itemName===item.id?'':item.id});}}>
        <View style={[styles.expandButtonRow,styles.btnExpand,styles.activeBackgroundColor]}>
          <Text style={styles.inactiveTintColor}>{item.txt}</Text>
          <Icon name={this.state.itemName===item.id?"ios-arrow-down":"ios-arrow-forward"} size={20} style={styles.customDrawerIcon}/>
        </View>
      </TouchableOpacity>
      {(
        this.state.itemName===item.id?
        item.childs.map( (it,i)=>( this.DrawSubItems(props,it.nav,it.txt,this.props.activeItemKey==it.nav?true:false) ) )
        :null
      )}
      </View>
    );
  }
  render(){
    return (<View style={styles.container}>
      <Text style={{textAlign: 'center'}}>Menu Items</Text>
      <View>{this.state.items.map( (it,i)=>(this.ButtonParents(this.props,it,i)) )}</View>
    </View>);
  }
}

const styles = StyleSheet.create({
  container:{flex: 1,paddingTop: Constants.statusBarHeight},
  customDrawerTouch: {paddingLeft: 15,paddingRight: 10},
  customDrawerIcon: { paddingRight: 1 },
  expandButtonRow: {
    flexDirection: 'row',
    paddingVertical: 12,paddingLeft: 3,borderBottomColor: '#F0F0F0',borderBottomWidth: 1
  },
  btnExpand:{justifyContent: 'space-between'},
  icon: {width: 24,height: 24},

  activeTintColor: {fontWeight: 'bold',color:'#2196f3'},
  activeBackgroundColor: {backgroundColor:'rgba(0, 0, 0, .04)'},
  inactiveTintColor: {fontWeight: 'bold',color:'rgba(0, 0, 0, .87)'},
  inactiveBackgroundColor: {backgroundColor:'transparent'},

});

const MyApp = DrawerNavigator({
  Home: {screen: Home},
  CreateUser: {screen:CreateUser},
  SearchUser: {screen: SearchUser},
  CreateRole: {screen:CreateRole},
  SearchRole: {screen: SearchRole},
  Notifications: {screen: Notifications}
  }, {
  contentComponent: MainDrawer
});
export default class App extends React.Component {
  render() { return (<MyApp />); }
}