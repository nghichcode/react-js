import React from 'react';
import {Text, View} from 'react-native';
import {Ionicons} from '@expo/vector-icons';
import { StackNavigator, TabNavigator, TabBarBottom } from 'react-navigation';

import HomeScreen from './components/HomeScreen'
import SettingsScreen from './components/SettingsScreen'
import ActivesScreen from './components/ActivesScreen'

const HomeStack = StackNavigator(
    {
        Home: { screen: HomeScreen },
    },
    {
        navigationOptions: {
            headerStyle: {backgroundColor: '#0099FF'},
            headerTintColor: '#FFFFFF',
            title: 'All',
        }
    }
);
const ActiveStack = StackNavigator(
  {
    Active: { screen: ActivesScreen },
  },
  {
      navigationOptions: {
      headerStyle: {backgroundColor: '#0099FF'},
      headerTintColor: '#FFFFFF',
      title: 'Active',
    }
  }
);
 
const SettingsStack = StackNavigator(
  {
    Settings: { screen: SettingsScreen },
  },
  {
      navigationOptions: {
      headerStyle: {backgroundColor: '#0099FF'},
      headerTintColor: '#FFFFFF',
      title: 'Commodetex',
    },
  });
 
export default TabNavigator(
  {
    Home: { screen: HomeStack },
    Active:{screen: ActiveStack},
    Settings: { screen: SettingsStack }
  },
  {
      navigationOptions: ({ navigation }) => ({
        tabBarIcon: ({ focused, tintColor }) => {
            const { routeName } = navigation.state;
            let iconName;
            if (routeName === 'Home') {
            iconName = `ios-list`;
        } else if (routeName === 'Active') {
            iconName = `ios-done-all`;
        } else if (routeName === 'Settings'){
          iconName = `ios-options`;
        }
        return <Ionicons name={iconName} size={25} color={tintColor} />
      }
    }),
    tabBarComponent: TabBarBottom,
    tabBarPosition: 'bottom',
    tabBarOptions: {
      activeTintColor: '#0099FF',
      inactiveTintColor: '#aaa',
    },
    animationEnabled: true,
    swipeEnabled: false,
  }
);