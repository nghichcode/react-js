import React, { Component } from 'react'
import { View, Text,TouchableHighlight,ListView, CheckBox } from 'react-native'
import {FontAwesome} from '@expo/vector-icons';

export default class App extends Component {
  constructor() {
    super();
    const ds = new ListView.DataSource({rowHasChanged: (r1, r2) => r1 !== r2});
    this.state = {
      dataSource: ds.cloneWithRows(['react', 'react native','redux','reactivesearch']),
    };
  }

  render() {
    return (
      <ListView
        dataSource={this.state.dataSource}
        renderRow={(rowData) => 
        <View style={{flex:1, marginTop:10}}>
        <View style={{flexDirection:'row'}}>
            <CheckBox iconType='material'/>
            <Text style={{paddingTop:5,marginLeft: 10}}>{rowData}</Text>
            <TouchableHighlight
                      style={{paddingTop:5,position:'absolute', right:10, }}
                      underlayColor='tomato'>
                      <FontAwesome name='trash-o' size={20}  style={{color:"red"}}/>
            </TouchableHighlight>
        </View>
      </View>}
      />
    );
  }
}