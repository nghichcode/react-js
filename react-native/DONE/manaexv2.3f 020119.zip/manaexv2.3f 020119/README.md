Routing :
App > Login > Home >

Home {CustInfor, CheckDetails}

	Home{CustInfor} > Account > 
						Setting > {goBack, Config (Err)}
						Description > goBack
						Home
	8. CheckDetails {CustInfor} > QRCamera > Details {CustInfor}